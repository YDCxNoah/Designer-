
function signUp() {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  auth.createUserWithEmailAndPassword(email, password)
    .then(() => alert("Signed up!"))
    .catch(err => alert(err.message));
}

function login() {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  auth.signInWithEmailAndPassword(email, password)
    .then(() => {
      document.getElementById('upload-section').style.display = 'block';
    })
    .catch(err => alert(err.message));
}

function logout() {
  auth.signOut()
    .then(() => {
      document.getElementById('upload-section').style.display = 'none';
      alert("Logged out!");
    });
}

function uploadImage() {
  const file = document.getElementById('fileInput').files[0];
  const name = document.getElementById('itemName').value;
  const storageRef = storage.ref('closet/' + file.name);
  const uploadTask = storageRef.put(file);

  uploadTask.on('state_changed', 
    null, 
    error => alert(error.message), 
    () => {
      uploadTask.snapshot.ref.getDownloadURL().then(downloadURL => {
        db.collection('closet').add({
          name: name,
          imageUrl: downloadURL,
          timestamp: new Date(),
          user: auth.currentUser.email
        });
        document.getElementById('uploadStatus').innerText = "Uploaded successfully!";
      });
    }
  );
}
